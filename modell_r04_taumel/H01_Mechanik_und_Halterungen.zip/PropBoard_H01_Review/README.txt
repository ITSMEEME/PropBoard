R04 – Mechanikreview und Halterungen H01

FreeCAD 1.0.2: modell_r04_taumel/halterungen/Halterungen_oeffnen.FCMacro ausfuehren.
Die neue Gesamtbaugruppe ist vollstaendig enthalten. Fuer native Einzelteile muss
halterungen_features.py neben dem Makro erhalten bleiben.

Zeichnungen: halterungen/Ausgabe/Halterungen_H01_Zeichnungen.pdf
Mechanikbericht: mechanik/Mechanikbericht.pdf und mechanik/README.md

Halterungen sind als Geometrie-/Montageentwurf geprueft. Keine Festigkeits- oder
Betriebsfreigabe. F01-Rotoranschluesse und Pitchwurzelreibung bleiben offen.
Servoauswahl_OFFEN.json nennt unbestaetigte Kandidaten: Herstellerabgleich wurde
von der Netz-Allowlist mit HTTP 403 blockiert. Keine Kauf- oder Einbaufreigabe.

Zur vollstaendigen Neuerzeugung dieses Pakets diese beiden Verzeichnisse in den
PropBoard-Checkout einordnen: Die vorhandenen cad/-Quellen und die F01-Baugruppe
werden als Basis verwendet. Das Oeffnen der mitgelieferten Gesamtbaugruppe und
Einzelteile benoetigt keinen vollstaendigen Repository-Checkout.

SHA256SUMS prueft die eingebetteten Daten. Vorschau-Quelldaten NPZ sind nicht
enthalten und koennen aus dem FreeCAD-Modell neu erzeugt werden.
