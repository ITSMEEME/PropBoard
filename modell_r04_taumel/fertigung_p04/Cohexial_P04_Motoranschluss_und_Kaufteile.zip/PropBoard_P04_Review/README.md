# Cohexial Study P04 – aktueller Motoranschluss

`modell_r04_taumel/fertigung_p04/P04_oeffnen.FCMacro` in FreeCAD starten.
Alternativ die gespeicherte native P04-Baugruppe unter `Ausgabe` öffnen.

Die bereitgestellte EMAX-Zeichnung bestätigt 4×M3 auf einem Lochkreis Ø16 mm.
Die vorherige Textangabe 16×16 war falsch. Entsprechende P03-CADs sind verworfen
und NICHT enthalten. Motorhöhe 31,6 mm und 13-mm-Abtriebsüberstand sind übernommen.

Das Motor-CAD ist ein Anschluss-/Grenzhüllenmodell eines vollständigen Kaufteils
nach der Zeichnung, keine Original-STEP oder Innenfertigungszeichnung. Nicht bemaßte
Lüftung/Fußkontur, M3-Blindtiefen und M5-Gewindelänge werden nicht erfunden.
Die Gesamtbaugruppe ist weiterhin GESPERRT; die verbleibenden Daten stehen in
`fertigung_p04/Noch_benoetigte_Daten_P04.md`.

P02-Dateien dienen als historische Basis und Quellen-/Normteilnachweis. Aktuell ist
P04. Die zusätzlichen Servo-/Lagerangaben der Textrecherche sind unverifizierte
Recherchebehauptungen, keine automatisch übernommenen Herstellerfreigaben.

Für Regeneration FreeCAD-Python/Part/MeshPart verwenden. Zum Öffnen der statisch
gepeicherten P04-Dokumente sind keine Community-Erzeuger nötig. Die bisherige
Flugsimulation/M01 und andere Fertigungsentwürfe sind im vollständigen Repository.
