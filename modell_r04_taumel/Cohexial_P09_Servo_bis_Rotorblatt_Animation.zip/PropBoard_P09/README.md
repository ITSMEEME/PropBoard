# P09 – gemeinsame Animation Servo bis Rotorblatt

Browser: modell_r04_taumel/bewegung_p09/Ausgabe/P09_Durchgaengige_Animation.html öffnen und Animation starten.
FreeCAD 1.0.2: modell_r04_taumel/bewegung_p09/P09_Bewegung_oeffnen.FCMacro ausführen.
Ordnerstruktur erhalten: runtime.py, bewegung_runtime.py und kinematik.json sind enthaltene Animationsabhängigkeiten.

Die native Baugruppe ist auch statisch direkt zu öffnen. Die README unter bewegung_p09 dokumentiert Konstruktion, Tests und offene Punkte.
Dies ist ein Bewegungs-/Konstruktionsentwurf, keine Fertigungs-/Flugfreigabe. Der vollständige Servo-STEP-Import ist weiterhin ungültig.
Für alle Fertigungsgeneratoren und Vorstufen ist der komplette Repository-Checkout ITSMEEME/PropBoard nötig.
