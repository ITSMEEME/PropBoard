# P10 – Servohalter, Planetenstufe, Kabelbaum, Landegestell

FreeCAD 1.0.2: modell_r04_taumel/integration_p10/P10_oeffnen.FCMacro ausführen (Animation inkl. Planeten).
Die native Baugruppe Ausgabe/P10_Gesamtbaugruppe.FCStd lässt sich auch statisch öffnen.
Beschreibung, Annahmen und offene Punkte: modell_r04_taumel/integration_p10/README.md.
Interaktive 3D-Flugsimulation: im Repository ITSMEEME/PropBoard modell_r04_taumel/simulation/H01_Flugsimulator.html.

Konstruktionsentwurf; keine Fertigungs-, Festigkeits-, Elektro- oder Flugfreigabe. Servo-STEP weiterhin ungültig.
