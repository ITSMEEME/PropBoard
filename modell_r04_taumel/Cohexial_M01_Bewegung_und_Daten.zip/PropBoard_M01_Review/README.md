# Cohexial Study M01 – Bewegung und Daten

1. `modell_r04_taumel/bewegung/Bewegung_oeffnen.FCMacro` in FreeCAD starten.
   Die native bewegliche FCStd-Datei liegt daneben im Unterordner `Ausgabe`.
   Das Makro lädt Solver/Zeitleiste und die zwei nominalen Servo-Geometrien.
2. `modell_r04_taumel/Datenbericht_M01.pdf` lesen: Nutzerangaben, berechnete
   Aerodynamik/Servolasten und fehlende Messungen werden ausdrücklich getrennt.
3. `modell_r04_taumel/simulation/H01_Flugsimulator.html` im Browser öffnen.
   Browser mit gesperrtem file://: im entpackten Ordner
   `python -m http.server 8000 --bind 127.0.0.1`, dann Seite über localhost öffnen.

Savöx SB-2271SG(+): Angaben 69 g, 6,0–7,4 V, 15/20 kg·cm, 0,08/0,06 s/60°.
KST X15-755X: 760 µs, nur Geometrie-Demo; weitere Last-/Signalwerte fehlen.
Realer Reibwert und experimentell validierte Aerodynamik liegen NICHT vor.
XFOIL-Kennwerte sind Berechnungen, die Identifikations-Testdaten synthetisch.
Servohalter, Spline-/Kugelaufnahmen, Dauerlast, BEC und Mechanikfreigaben sind offen.

Native M01-Innenteile von Lager/Motor sind Funktionsschemata, keine Hersteller-
fertigungszeichnungen. Die interne Getriebestufe des Kaufservos ist unbekannt.
Flugwiedergabe in FreeCAD löst Kinematik, keine neue Kraft-/Kontaktdynamik.

Node-Flugversuche ohne weitere Pakete:
`node modell_r04_taumel/simulation/testflug.js`
`node modell_r04_taumel/simulation/pruefen.js`

Python-Auswertungen: numpy; Plots: matplotlib; PDF: reportlab.
Optionaler Browser-Test benötigt Playwright/Chromium. CAD-Erzeugung benötigt
FreeCAD Python/Part/MeshPart; die genutzten Tools selbst sind nicht enthalten.

Die vollständigen älteren Fertigungszeichnungen bleiben im separaten H01-Paket
und Repository ITSMEEME/PropBoard. Einige weiterführende Alt-Links fehlen hier.
