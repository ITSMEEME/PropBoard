P08 mechanische Servoverbindung – detaillierter Entwurf, keine Fertigungsfreigabe.

Native Baugruppen und STEP unter fertigung_p08/Ausgabe.
Fuer die isolierte Bewegung fertigung_p08/P08_Bewegung_oeffnen.FCMacro mit FreeCAD1.0.2 ausfuehren.
Ordnerstruktur erhalten: bewegung und simulation enthalten die Kinematik-Abhaengigkeiten.

Die kompletten CAD-Generatoren und vorherigen Baugruppen zur Regeneration befinden sich im Repository ITSMEEME/PropBoard.
Servo-Originalimport geometrisch ungueltig; lokale Abtriebsableitung separat gueltig. Alle offenen Punkte stehen in fertigung_p08/README.md und Anschlussdaten.json.
