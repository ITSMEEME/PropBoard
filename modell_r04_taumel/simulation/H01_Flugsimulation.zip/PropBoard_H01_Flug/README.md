# Cohexial Study H01 – Offline-Flugsimulation

Öffne `modell_r04_taumel/simulation/H01_Flugsimulator.html` im Browser (WebGL).
Die 3D-Ansicht zeigt die native P10-Baugruppe (Servohalter, Planetenstufe, Kabelbaum, Landegestell),
animiert aus dem Physikzustand; „Start“ hebt vom Boden ab. Beschreibung: `modell_r04_taumel/integration_p10/README.md`.
Der `Flugbericht.pdf` und die README stehen daneben.

Das tatsächliche native FreeCAD-Modell liegt unter
`modell_r04_taumel/halterungen/Ausgabe/R04_Taumelmodell_Halterungen_H01.FCStd`.
Das zusätzliche bewegliche M01-Modell liegt unter `modell_r04_taumel/bewegung/`;
zum Bewegen `Bewegung_oeffnen.FCMacro` in FreeCAD starten. Savöx-Hüllen/-Daten stammen aus Nutzerangaben.
Masse, Schwerpunkt, Tensor und Sichtgeometrie des Grundmodells wurden aus H01 importiert;
das SHA256 der nativen Quelle steht in `simulation/modell_h01.json`.

Node ohne weitere Pakete:
- `node modell_r04_taumel/simulation/testflug.js`
- `node modell_r04_taumel/simulation/pruefen.js`
- `node modell_r04_taumel/simulation/robustheit.js`

Browser mit gesperrtem file://: im entpackten Ordner
`python -m http.server 8000 --bind 127.0.0.1`, danach die HTML-Seite über localhost öffnen.
Die Zeichnungen und vollständigen CAD-Generatoren sind im separaten H01-Fertigungspaket
oder im Repository ITSMEEME/PropBoard. Weiterführende Repository-Links können hier fehlen.

Unvalidierte Modellversuche, keine Flugfreigabe. Servo-/Reibungsdaten sind Annahmen.
PID-Werte nicht ungeprüft auf reale Hardware übertragen.
