# FreeCAD-Konzeptdateien

- `Hexacopter_650_Konzept.FCStd`: sechs 650-mm-Rotorreferenzen, Ringe, Deck und neu angenommene Strukturplatzhalter.
- `Hexacopter_Tattu41000_8Packs.FCStd`: zusätzlich acht maßhaltige Tattu-Gehäuse an den übergebenen Positionen.
- `Tmotor_X605_Bauraum.FCStd`: vereinfachter Motorzylinder und bewusst überlappende Referenzhülle. Kein bestätigtes Produktmodell und kein integrierter Antriebsentwurf.

Die Dateien enthalten editierbare Part-Grundkörper, boolesche Ring-Differenzen und in den Boarddateien eine Parametertabelle mit Expressions. Rotorwirkflächen sind ausgeblendet; sie lassen sich im Modellbaum einblenden. Maße in mm.

Erzeugung im Repository-Verzeichnis:

```sh
/usr/bin/python3 cad/erstellen.py
```

Hier wurde FreeCAD 1.0 über seine Python-Schnittstelle verwendet. Der separate Starter `freecadcmd --version` stürzt in dieser Umgebung ab. Der Bibliothekspfad im Skript gilt für diese Linux-Installation.

## Neue Annahmen und Grenzen

Die Originaldateien fehlen. Rahmen, Motorplatzhalter, Deckstützen und Landefüße wurden neu als einfache Visualisierungsgeometrie angenommen. Sie rekonstruieren keine unbekannten Originaldetails. Die Fahrzeughülle beträgt 2060 × 1690 × 320 mm; die Höhe entsteht aus der angenommenen Fahrwerksunterkante z = −90 und der Deckoberkante z = 230.

Querträger folgen den Rasterparametern, Längsträger, Deckstützen und Fahrwerk sind jedoch nicht vollständig rasterabhängig. Geänderte Geometrien müssen erneut auf Abstände und Außenmaße geprüft werden. Es gibt keinen Nachweis einer zusammenhängenden tragfähigen Struktur, von Schutzwirkung oder ausreichender Rotorfreiheit im Betrieb. Motorplatzhalter sind keine realen Antriebe. Stecker, Verkabelung, Kühlung, Halter und Akkuausdehnung fehlen.

Der X605 wird nicht automatisch in das Board eingebaut. Seine Achsenlage innerhalb der Hülle ist eine ausdrücklich benannte Annahme. Die überlappende Hülle dient nur als Referenz.

## Ausgeführte Prüfungen

`Pruefbericht.json` dokumentiert die aktuelle Erzeugung: alle drei Dokumente gespeichert und erneut geöffnet, vorhandene Formen auf geometrische Gültigkeit geprüft, Board-Außenmaße geprüft, Rotordurchmesser geändert und zurückgesetzt. In der Tattu-Variante wurden mindestens 10 mm zwischen Packgehäusen und positive Abstände zu anderen modellierten Ergebnisobjekten geprüft.

Diese Prüfungen sind geometrisch. Keine Flug-, Struktur-, Schutz- oder Leistungsvalidierung. Keine Fertigungszeichnungen.
